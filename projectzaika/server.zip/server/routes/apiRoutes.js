const router= require("express").Router()
const multer=require("multer")
const storage=multer.memoryStorage()
const upload=multer({storage: storage})

// menu
const menuController= require("../api/menu/menuController")
router.post("/menu/add",upload.single("image"),menuController.add),
router.post("/menu/all",menuController.all)






module.exports = router