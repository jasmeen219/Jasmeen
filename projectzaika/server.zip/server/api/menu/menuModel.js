const mongoose= require("mongoose");
const menuSchema=mongoose.Schema({
    autoId:{ type:Number, default:''},
    name:{ type:String, default:''},
    description:{ type:String, default:''},
    price:{ type:Number, default:''},
    image:{ type:String, default:''},
    category:{ type:String,default:''},
    status:{ type:Boolean,default:true},
    created_at:{ type:Date,default:Date.now()}

})
module.exports=mongoose.model("menu",menuSchema)
