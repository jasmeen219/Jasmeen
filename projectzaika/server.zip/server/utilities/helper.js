const cloudinary = require("cloudinary").v2;
cloudinary.config({
    cloud_name: "dmipupiy3",
    api_key: "147963557176623",
    api_secret: "3g1mSMt7bCbJIpdcDM8Pn6JbLHM",
    secure: true,
    cdn_subdomain: true,
});




const uploadImg = async (fileBuffer, publicId) => {
    return new Promise((resolve, reject) => {
        cloudinary.uploader.upload_stream(
            {
                public_id: publicId,
                resource_type: "auto" },
            (error, result) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(result.secure_url);
                }
            }
        ).end(fileBuffer);
    });
};




module.exports = {uploadImg}